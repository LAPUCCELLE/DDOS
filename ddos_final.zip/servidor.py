import socket
import threading
import time
import random
from http.server import SimpleHTTPRequestHandler, HTTPServer

ftp_activo = True
telnet_activo = True
errores_consecutivos_telnet = 0
max_errores_telnet = 1000
conexiones_ftp = 0
limite_conexiones_simultaneas = 5 

class manejohttp(SimpleHTTPRequestHandler):
    def do_GET(self):
        self.send_response(200)
        self.send_header("Content-type", "text/html")
        self.end_headers()
        contenido = "<html><body><h1>Servidor en linea</h1></body></html>"
        time.sleep(random.uniform(1, 5))
        self.wfile.write(contenido.encode('utf-8'))

def servidor_http(ip='0.0.0.0', puerto=80):
    http = HTTPServer((ip, puerto), manejohttp)
    print(f'Servidor HTTP escuchando en {ip}:{puerto}...')
    http.serve_forever()

def sobrecarga_simulada():
    print("Servidor FTP sobrecargado. Esperando que se liberen conexiones...")

def manejoftp(conn, addr):
    global conexiones_ftp
    global ftp_activo
    if not ftp_activo or conexiones_ftp >= limite_conexiones_simultaneas:
        print("Servidor FTP saturado y cerrado.")
        conn.send(b"El servidor FTP esta sobrecargado, intente despues.\r\n")
        conn.close()
        return
    conexiones_ftp += 1
    print(f'Conexion FTP establecida con {addr}')
    conn.send(b"Bienvenido al servidor FTP\r\n")
    try:
        while True:
            data = conn.recv(1024).decode("utf-8").strip()
            if not data:
                break
            print(f"Comando recibido de: {data}")
            if data.upper() == "QUIT":
                conn.send(b"Cerrando la conexion\r\n")
                break
            elif data.upper().startswith("USER") or data.upper().startswith("PASS"):
                conn.send(b"Usuario autenticado\r\n")
            else:
                conn.send(b"Comando no implementado\r\n")
            time.sleep(random.uniform(0.1, 1))
    except Exception as e:
        print(f"Error en la conexion FTP: {e}")
    finally:
        conn.close()
        conexiones_ftp -= 1
        print(f'Conexión FTP cerrada con {addr}')
        if conexiones_ftp < limite_conexiones_simultaneas:
            print(f"Servidor FTP disponible nuevamente.")

def servidor_ftp(ip='0.0.0.0', puerto=2121):
    global ftp_activo
    ftp = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    ftp.bind((ip, puerto))
    ftp.listen(5)
    print(f'Servidor FTP escuchando en {ip}:{puerto}...')
    while ftp_activo:
        try:
            conn, addr = ftp.accept()
            threading.Thread(target=manejoftp, args=(conn, addr)).start()
        except Exception as e:
            print(f"Error en la conexión FTP: {e}")
            if not ftp_activo:
                break

def manejotelnet(conn, addr):
    global telnet_activo
    global errores_consecutivos_telnet
    if not telnet_activo:
        print("Servidor Telnet saturado y cerrado.")
        return
    print(f'Conexion Telnet establecida con direccion {addr}')
    conn.send(b"Bienvenido al servidor Telnet\r\n")
    try:
        while True:
            data = conn.recv(1024).decode("utf-8").strip()
            if not data:
                break
            print(f"Comando Telnet recibido de: {data}")
            if data.upper() == "QUIT":
                conn.send(b"Adios\r\n")
                break
            else:
                conn.send(b"Solicitud invalida\r\n")
                errores_consecutivos_telnet += 1
                print(f"Errores consecutivos Telnet: {errores_consecutivos_telnet}")
                if errores_consecutivos_telnet >= max_errores_telnet:
                    print("Se alcanzó el máximo de errores consecutivos en Telnet. Cerrando servidor Telnet.")
                    telnet_activo = False
                    break
            time.sleep(random.uniform(2, 5))
    except Exception as e:
        print(f"Error en la conexion Telnet: {e}")
    finally:
        conn.close()
        print(f'Conexión Telnet cerrada con la direccion {addr}')

def servidor_telnet(ip='0.0.0.0', puerto=23):
    global telnet_activo
    telnet = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    telnet.bind((ip, puerto))
    telnet.listen(5)
    print(f'Servidor Telnet escuchando en {ip}:{puerto}...')
    while telnet_activo:
        try:
            conn, addr = telnet.accept()
            threading.Thread(target=manejotelnet, args=(conn, addr)).start()
        except Exception as e:
            print(f"Error en la conexión Telnet: {e}")
            if not telnet_activo:
                break

if __name__ == "__main__":
    ip_servidor = '0.0.0.0'
    puerto_http = 80
    puerto_ftp = 2121
    puerto_telnet = 23
    threading.Thread(target=servidor_http, args=(ip_servidor, puerto_http)).start()
    threading.Thread(target=servidor_ftp, args=(ip_servidor, puerto_ftp)).start()
    threading.Thread(target=servidor_telnet, args=(ip_servidor, puerto_telnet)).start()
